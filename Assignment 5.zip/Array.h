#ifndef ARRAY_H
#define ARRAY_H

#include <iostream>
using namespace std;

class Array {
private:
	int size;
	int* ptr;
	static int total;
	static bool isSrand;
public:
	Array(int s);
	Array(const Array& obj);
	~Array();
	int getSize();
	bool operator==(const Array& obj);
	bool operator<(const Array& obj);
	Array& operator!();
	int operator*();
	void operator+=(const Array& obj);
	Array& operator--();
	Array operator++(int);
	void operator=(const Array& obj);
	int& operator[](int index);
	static int getNumberOfElements() {
		return total;
	}
	friend ostream& operator<<(ostream& os, const Array& arr);
};

#endif