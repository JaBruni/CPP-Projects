#include "composer.h"

Composer::Composer() {
	name = "";
	year = 0;
}

Composer::Composer(string n, int y) {
	name = n;
	year = y;
}

void Composer::setName(string n) {
	name = n;
}

string Composer::getName() const {
	return name;
}

void Composer::setYear(int y) {
	year = y;
}

int Composer::getYear() const{
	return year;
}

bool Composer::operator==(const Composer& obj) {
	return(name == obj.name);
}

bool Composer::operator!=(const Composer& obj) {
	return(name != obj.name);
}

bool Composer::operator>(const Composer& obj) {
	if (year < obj.year) {
		return false;
	}
	else if (year > obj.year) {
		return true;
	}
	return false;
}

bool Composer::operator<(const Composer& obj) {
	if (year > obj.year) {
		return false;
	}
	else if (year < obj.year) {
		return true;
	}
	return false;
}

ostream& operator<<(ostream & os, const Composer & obj) {
	os << obj.name << " - " << obj.year;
	return os;
}