#ifndef COMPOSER_H
#define COMPOSER_H

#include<iostream>
using namespace std;

class Composer {
private:
	string name;
	int year;
public:
	Composer();
	Composer(string name, int year);
	string getName() const;
	void setName(string n);
	int getYear() const;
	void setYear(int y);
	bool operator==(const Composer& obj);
	bool operator!=(const Composer& obj);
	bool operator<(const Composer& obj);
	bool operator>(const Composer& obj);
	friend ostream& operator<<(ostream& os, const Composer& obj);
};
#endif