#include "Array.h"
#include <ctime>

//Initializes the total number of elements to 0
int Array::total = 0;

//Initalizes isSrand to false
bool Array::isSrand = false;

//Overloaded constructor
//Accepts an integer argument that represents the size of the array
Array::Array(int s) {
	size = s;
	total = total + s;
	ptr = new int[size];
	if (!isSrand) {
		srand(time(0));
		isSrand = true;
	}
}

//Copy Constructor
//Accepts an Array object passed by constant reference
//Initializes new Array object
Array::Array(const Array& obj) {
	this->size = obj.size;
	total = total + this->size;
	this->ptr = new int[size];
	for (int i = 0; i < size; i++) {
		this->ptr[i] = obj.ptr[i];
	}
}

//Destructor
//Cleans the Heap
Array::~Array() {
	total = total - size;
	delete ptr;
}

//Returns the size of the array
int Array::getSize() {
	return size;
}

//Overloaded assignment operator
//Replaces the contents of existing Array objects
void Array::operator=(const Array& obj) {
	if (this == &obj) {
		return;
	}
	total = total - this->size;
	this->size = obj.size;
	delete this->ptr;
	this->ptr = new int[size];
	total = total + this->size;
	for (int i = 0; i < size; i++) {
		this->ptr[i] = obj.ptr[i];
	}
}

//Overloaded equality operator
//Returns true if one Array object an in-order subset of another Array object.
//Returns false if the Array object is not a subset of another Array object.
bool Array::operator==(const Array& obj) {
	for (int i = 0; i < size; i++) {
		if (this->ptr[i] == obj.ptr[i]) {
				return true;
		}
		else if (this->ptr[i] != obj.ptr[i]) {
				return false;
		}
	}
}

//Overloaded less-than operator
//Compares two Array objects element-by-element
//Returns true if the first element in the first Array is less than the 
//first element in the second Array.
bool Array::operator<(const Array& obj) {
	for (int i = 0; i < size; i++) {
		if (this->ptr[i] > obj.ptr[i]) {
			return false;
		}
		else if (this->ptr[i] < obj.ptr[i]) {
			return true;
		}
	}
	return false;
}

//Overloaded compound sum operator
//Appends the right-hand Array object to the lest-hand Array object without
//changing the right-hand Array object.
void Array::operator+=(const Array& obj) {
	int size = this->size;
	this->size = this->size + obj.size;
	total = total + obj.size;
	int* temp = new int[this->size];
	for (int i = 0; i < size; i++) {
		temp[i] = ptr[i];
	}
	for (int i = 0; i < obj.size; i++) {
		temp[size + i] = obj.ptr[i];
	}
	delete this->ptr;
	ptr = temp;
}

//Overloaded not operator
//Randomnly shuffles the elements in the array
Array& Array::operator!() {
	for (int i = 0; i < size; i++) {
		int pos = rand() % size;
		int temp = ptr[i];
		ptr[i] = ptr[pos];
		ptr[pos] = temp;
	}
	return *this;
}

//Overloaded indirection operator
//Returns the smallest value inside the Array object
int Array::operator*() {
	int smallest = ptr[0];
	for (int i = 1; i < size; i++) {
		if (smallest > ptr[i]) {
			smallest = ptr[i];
		}
	}
	return smallest;
}

//Overloaded postfix increment operator
//Increments the elements of the array, 
//but the value of the array is the same.
Array Array::operator++(int) {
	Array temp(*this);
	for (int i = 0; i < size; i++) {
		ptr[i]++;
	}
	return temp;
}

//Overloaded prefix decrement operator
//Decrements the elements of the array, 
//and the values of the the array have changed.
Array& Array::operator--() {
	for (int i = 0; i < size; i++) {
		ptr[i]--;
	}
	return *this;
}

//Overloaded index operator
//Returns a reference 
int& Array::operator[](int index) {
	return ptr[index];
}

//Overloaded ostream operator
//Performs outputs for array objects
ostream& operator<<(ostream& os, const Array& arr) {
	for (int i = 0; i < arr.size; i++) {
		os << arr.ptr[i] << " ";
	}
	os << endl;
	return os;
}