// Jason Bruni
// This program creates a simple list of composers from a templated linked
// list. The user can choose to search, remove, and display the composers. The 
// user can also exit.

#include "LinkedList.h"
#include "Composer.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;
void readInput(LinkedList<Composer> &CompList);
int main() {
    LinkedList<Composer> CompList;
    Composer c1;
    readInput(CompList);
    char choice;
    string name;
    bool found;
    while (true) {
        cout << endl;
        cout << "Enter 's' to search, 'r' to remove, 'd' to display "
            << "or 'e' to exit: ";

        
        cin >> choice;
        cout << endl;
        
        if (choice == 's' || choice == 'S') {
            cout << "Enter a composer's name to search for: ";
            cin.ignore();
            getline(cin, name);
            c1.setName(name);
            found = CompList.find(c1);
            if (found) {
                cout << name << " was found in the list" << endl;
            }
            else {
                cout << name << " was not found in the list" << endl;
            }
        }
        else if (choice == 'r' || choice == 'R') {
            cout << "Enter a composer's name to remove: ";
            cin.ignore();
            getline(cin, name);
            c1.setName(name);
            found = CompList.remove(c1);
            if (found) {
                cout << name << " was succesfully removed from the list" << endl;
            }
            else {
                cout << name << " was not found to remove" << endl;
            }

        }
        else if (choice == 'd' || choice == 'D') {
            CompList.printList();
        }
        else if (choice == 'e' || choice == 'E') {
            return 0;
        }

    }
    return 0;
}


void readInput(LinkedList<Composer> &CompList) {
    ifstream inFile;
    inFile.open("composers.txt");
    if (!inFile.is_open()) {
        cout << "Unable to read file." << endl;
        exit(1);
    }

    string name;
    string buffer;
    int year;

    while (true) {
        getline(inFile, name, ',');
        if (inFile.eof())
            break;
        inFile >> year;
        Composer c1(name, year);
        CompList.insert(c1);
        getline(inFile, buffer);
        
    }
    inFile.close();
}


//Enter 's' to search, 'r' to remove, 'd' to display or 'e' to exit : d
//
//Claudio Monteverdi - 1643
//Henry Purcell - 1695
//Antonio Vivaldi - 1741
//Johann Sebastian Bach - 1750
//George Frideric Handel - 1759
//Wolfgang Amadeus Mozart - 1791
//Joseph Haydn - 1809
//Ludwig van Beethoven - 1827
//
//Enter 's' to search, 'r' to remove, 'd' to display or 'e' to exit : s
//
//Enter a composer's name to search for: Claudio Monteverdi
//Claudio Monteverdi was found in the list
//
//Enter 's' to search, 'r' to remove, 'd' to display or 'e' to exit : s
//
//Enter a composer's name to search for: Hanz Zimmer
//Hanz Zimmer was not found in the list
//
//Enter 's' to search, 'r' to remove, 'd' to display or 'e' to exit : r
//
//Enter a composer's name to remove: Henry Purcell
//Henry Purcell was succesfully removed from the list
//
//Enter 's' to search, 'r' to remove, 'd' to display or 'e' to exit : r
//
//Enter a composer's name to remove: Daft Punk
//Daft Punk was not found to remove
//
//Enter 's' to search, 'r' to remove, 'd' to display or 'e' to exit : d
//
//Claudio Monteverdi - 1643
//Antonio Vivaldi - 1741
//Johann Sebastian Bach - 1750
//George Frideric Handel - 1759
//Wolfgang Amadeus Mozart - 1791
//Joseph Haydn - 1809
//Ludwig van Beethoven - 1827
//
//Enter 's' to search, 'r' to remove, 'd' to display or 'e' to exit : e