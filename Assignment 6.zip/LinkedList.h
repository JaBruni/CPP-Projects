#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "Node.h"
#include <iostream>
using namespace std;

template<class T>
class LinkedList {
private:
	Node<T>* head;
	Node<T>* tail;
public:
	LinkedList();
	~LinkedList();
	void printList() const;
	void append(const T data);
	void prepend(const T data);
	bool removeFront();
	void insert(const T data);
	bool remove(const T data);
	bool find(const T data);
	bool isEmpty() const;
	T getFirst() const;
	T getLast() const;
};

template<class T>
LinkedList<T>::LinkedList(){
	head = nullptr;
	tail = nullptr;
}

template<class T>
LinkedList<T>::~LinkedList() {
	Node<T> *temp = head;
	while (temp) {
		head = head->next;
		delete temp;
		temp = head;
	}
}

template<class T>
void LinkedList<T>::printList() const {
	Node<T> *temp = head;
	while (temp) {
		cout << temp->value << endl;
		temp = temp->next;
	}
}

template<class T>
void LinkedList<T>::append(const T data) {
	Node<T> *temp = new Node<T>(data);
	if (head == nullptr) {
		head = temp;
		tail = temp;
		return;
	}

	tail->next = temp;
	tail = temp;
}

template<class T>
void LinkedList<T>::prepend(const T data) {
	Node<T> *temp = new Node<T>(data);
	if (head == nullptr) {
		head = temp;
		tail = temp;
		return;
	}

	temp->next = head;
	head = temp;
}

template<class T>
bool LinkedList<T>::removeFront() {
	Node<T>* temp = head;
	head = head->next;
	delete temp;
	return true;

	if (head == nullptr) {
		return false;
	}
}

template<class T>
void LinkedList<T>::insert(const T data) {
	Node<T>* temp = new Node<T>(data);
	if (head == nullptr)
	{
		temp->next = nullptr;
		head = tail = temp;
		return;
	}

	Node<T>* preNode = head;
	Node<T>* current = head;
	if (current->value > data)
	{
		temp->next = head;
		head = temp;
		return;
	}

	//traverse the list
	while (current != nullptr && current->value < data)
	{
		preNode = current;
		current = current->next;
	}

	if (current != nullptr && current->value > data) {
		temp->next = current;
		preNode->next = temp;
	}

	

}

template<class T>
bool LinkedList<T>::remove(const T data) {
	if (head == nullptr)
		return false;

	Node<T>* preNode;
	Node<T>* current;
	current = head;
	preNode = head;
	if (current->value == data) {
		head = current->next;
		current->next = nullptr;
		delete current;
		return true;
	}

	while (current && current->value != data) {
		preNode = current;
		current = current->next;
	}
	if (current == nullptr)
		return false;
	preNode->next = current->next;
	current->next = nullptr;
	delete current;
	return true;
}

template<class T>
bool LinkedList<T>::find(const T data) {
	Node<T>* temp = head;
	while (temp) {
		if (temp->value == data)
			return true;
		temp = temp->next;
	}
	return false;
}

template<class T>
bool LinkedList<T>::isEmpty() const {
	if (head == nullptr) {
		return true;
	}
	return false;
}

template<class T>
T LinkedList<T>::getFirst() const {
	return head->value;
}

template<class T>
T LinkedList<T>::getLast() const {
	return tail->value;
}
#endif
